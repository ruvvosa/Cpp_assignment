#pragma once
#include "Monster.h"
#include <conio.h>
enum Direction { Left = 75, Right = 77, Up = 72, Down = 80 };

class Human : public Monster {
public:
	Human(string n = "�̷��η�", string i = "��", int px = 0, int py = 0)
		: Monster(n, i, px, py) {
	}
	~Human() { cout << "Human"; }
	int getDirkey() { return _getche() == 224 ? _getche() : 0; }
	void move(int map[DIM][DIM], int maxx, int maxy, unsigned char ch) {
		if (ch == Left || ch == 'a') p[0]--;
		else if (ch == Right || ch == 'd') p[0]++;
		else if (ch == Up || ch == 'w') p[1]--;
		else if (ch == Down || ch == 's') p[1]++;
		else return;
		clipAndEat(map, maxx, maxy);
	}
};

class Tuman : public Human {
public:
	Tuman(string n = "�̷��η�", string i = "��", int px = 0, int py = 0)
		: Human(n, i, px, py) {
	}
	void move(int map[DIM][DIM], int maxx, int maxy, unsigned char ch) {
		if (ch == Left || ch == 'a') p[0]--;
		else if (ch == Right || ch == 'd') p[0]++;
		else if (ch == Up || ch == 'w') p[1]--;
		else if (ch == Down || ch == 's') p[1]++;
		else return;
		clipAndEat(map, maxx, maxy);
	}
	virtual void move(int map[DIM][DIM], int maxx, int maxy) {}
};