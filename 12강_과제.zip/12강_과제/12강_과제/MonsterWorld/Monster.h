﻿#pragma once
#include "Canvas.h"
#include "Point.h"
#define DIM 40

class Monster {
	string name, icon;
	int nItem, nEnergy;
	static int mCount;

	void eat(int map[DIM][DIM]) {
		if (map[p[1]][p[0]] == 1) {
			map[p[1]][p[0]] = 0;
			nItem++;
			nEnergy += 8;
		}
		else {
			if (nEnergy > 0) nEnergy--;
		}
	}

protected:
	Point p; 

	void clip(int maxx, int maxy) {
		p(maxx, maxy); 
	}
	void clipAndEat(int map[DIM][DIM], int maxx, int maxy) {
		clip(maxx, maxy);
		eat(map);
	}

public:
	Monster(string n = "나괴물", string i = "※", int px = 0, int py = 0)
		: name(n), icon(i), p(px, py), nItem(0), nEnergy(100) { 
		mCount++;
	}
	virtual ~Monster() {
		mCount--;
		cout << "\t" << name << icon << " 물러갑니다~~~\n";
	}

	void draw(Canvas& canvas) {
		canvas.draw(p[0], p[1], icon); 
	}

	virtual void move(int map[DIM][DIM], int maxx, int maxy) {
		switch (rand() % 8) {
		case 0: p += Point(0, -1); break;
		case 1: p += Point(1, -1); break;
		case 2: p += Point(1, 0); break;
		case 3: p += Point(1, 1); break;
		case 4: p += Point(0, 1); break;
		case 5: p += Point(-1, 1); break;
		case 6: p += Point(-1, 0); break;
		case 7: p += Point(-1, -1); break;
		}
		clipAndEat(map, maxx, maxy);
	}

	int getEnergy() const { return nEnergy; }
	int getItem() const { return nItem; }  
	void print() const {
		cout << "\t" << name << icon << " 위치:" << const_cast<Point&>(p)
			<< " :" << nItem << " E:" << nEnergy << endl;
	}
	static void printCount() {
		cout << " 전체 몬스터의 수 " << mCount << "\n";
	}
	static int getCount() { return mCount; }
};
int Monster::mCount = 0;

// Smombi - 대각선으로만 이동
class Smombi : public Monster {
public:
	Smombi(string n = "스몸비", string i = "⊙", int px = 0, int py = 0)
		: Monster(n, i, px, py) {
	}
	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		switch (rand() % 4) {
		case 0: p += Point(1, -1); break;
		case 1: p += Point(1, 1); break;
		case 2: p += Point(-1, 1); break;
		case 3: p += Point(-1, -1); break;
		}
		clipAndEat(map, maxx, maxy);
	}
};

// Jiangshi - 가로 또는 세로 한 방향으로만 이동
class Jiangshi : public Monster {
protected:
	bool horizontal;
public:
	Jiangshi(string n = "강시", string i = "⊕", int px = 0, int py = 0)
		: Monster(n, i, px, py), horizontal(rand() % 2 == 0) {
	}
	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		if (horizontal) p[0] += (rand() % 2 == 0) ? 1 : -1;
		else             p[1] += (rand() % 2 == 0) ? 1 : -1;
		clipAndEat(map, maxx, maxy);
	}
};

// Siangshi - N턴마다 방향 전환
class Siangshi : public Jiangshi {
	int turnCount, switchEvery;
public:
	Siangshi(string n = "샹시", string i = "◈", int px = 0, int py = 0, int sw = 5)
		: Jiangshi(n, i, px, py), turnCount(0), switchEvery(sw) {
	}
	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		if (++turnCount % switchEvery == 0) horizontal = !horizontal;
		Jiangshi::move(map, maxx, maxy);
	}
};

// Phantom - N턴마다 순간이동
class Phantom : public Monster {
	int waitCount, waitEvery;
public:
	Phantom(string n = "팬텀", string i = "▣", int px = 0, int py = 0, int we = 8)
		: Monster(n, i, px, py), waitCount(0), waitEvery(we) {
	}
	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		if (++waitCount % waitEvery == 0) {
			p[0] = rand() % maxx;
			p[1] = rand() % maxy;
		}
		clipAndEat(map, maxx, maxy);
	}
};

