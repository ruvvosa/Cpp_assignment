﻿#pragma once
#include "Canvas.h"	
#define DIM 40
class Monster {
	string name, icon;
	int nItem, nEnergy;
	static int mCount;
	void clip(int maxx, int maxy) {
		if (x < 0) x = 0;
		if (x >= maxx) x = maxx - 1;
		if (y < 0) y = 0;
		if (y >= maxy) y = maxy - 1;
	}
	void eat(int map[DIM][DIM]) {
		if (map[y][x] == 1) {
			map[y][x] = 0;
			nItem++;
			nEnergy += 8;
		}
		else {
			if (nEnergy > 0)
				nEnergy--;
		}
	}
protected:
	int x, y;
	void clipAndEat(int map[DIM][DIM], int maxx, int maxy) {
		clip(maxx, maxy);
		eat(map);
	}
public:
	Monster(string n = "나괴물", string i = "※", int px = 0, int py = 0)
		: name(n), icon(i), x(px), y(py), nItem(0), nEnergy(100) {
		mCount++;
	}
	virtual ~Monster() {
		mCount--;
		cout << "\t" << name << icon << " 물러갑니다~~~\n";
	}
	void draw(Canvas& canvas) { canvas.draw(x, y, icon); }
	virtual void move(int map[DIM][DIM], int maxx, int maxy) {
		switch (rand() % 8) {
		case 0: y--; break;
		case 1: x++; y--; break;
		case 2: x++; break;
		case 3: x++; y++; break;
		case 4: y++; break;
		case 5: x--; y++; break;
		case 6: x--; break;
		case 7: x--; y--; break;
		}
		clip(maxx, maxy);
		eat(map);
	}
	int getEnergy() const { return nEnergy; }
	void print() const {
		cout << "\t" << name << icon << " :" << nItem
			<< " E:" << nEnergy << endl;
	}
	static void printCount() {
		cout << " 전체 몬스터의 수 " << mCount << "\n";
	}
	static int getCount() { return mCount; }
};
int Monster::mCount = 0;

//  Smombi - 대각선으로만 이동
// 
class Smombi : public Monster {
public:
	Smombi(string n = "스몸비", string i = "⊙", int px = 0, int py = 0)
		: Monster(n, i, px, py) {
	}

	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		switch (rand() % 4) {
		case 0: x++; y--; break; // 우상
		case 1: x++; y++; break; // 우하
		case 2: x--; y++; break; // 좌하
		case 3: x--; y--; break; // 좌상
		}
		clipAndEat(map, maxx, maxy);
	}
};

// Jiangshi - 강시: 가로 또는 세로 한 방향으로만 이동
class Jiangshi : public Monster {
protected:
	bool horizontal; // true: 가로, false: 세로
public:
	Jiangshi(string n = "강시", string i = "⊕", int px = 0, int py = 0)
		: Monster(n, i, px, py), horizontal(rand() % 2 == 0) {
	}

	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		if (horizontal) {
			if (rand() % 2 == 0) x++;
			else                  x--;
		}
		else {
			if (rand() % 2 == 0) y++;
			else                  y--;
		}
		clipAndEat(map, maxx, maxy);
	}
};

//  Siangshi - 샹시: Jiangshi 상속, N턴마다 방향 전환
class Siangshi : public Jiangshi {
	int turnCount;
	int switchEvery;
public:
	Siangshi(string n = "샹시", string i = "◈", int px = 0, int py = 0, int sw = 5)
		: Jiangshi(n, i, px, py), turnCount(0), switchEvery(sw) {
	}

	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		turnCount++;
		if (turnCount % switchEvery == 0)
			horizontal = !horizontal;
		Jiangshi::move(map, maxx, maxy);
	}
};

// (3) Phantom - 자유 클래스: Monster 상속, N턴마다 순간이동
class Phantom : public Monster {
	int waitCount;
	int waitEvery;
public:
	Phantom(string n = "팬텀", string i = "▣", int px = 0, int py = 0, int we = 8)
		: Monster(n, i, px, py), waitCount(0), waitEvery(we) {
	}

	virtual void move(int map[DIM][DIM], int maxx, int maxy) override {
		waitCount++;
		if (waitCount % waitEvery == 0) {
			x = rand() % maxx;
			y = rand() % maxy;
		}
		clipAndEat(map, maxx, maxy);
	}
};