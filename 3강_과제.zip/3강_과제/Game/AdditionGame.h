extern double tAddElapsed;
double playAdditionGame(int nPlay);