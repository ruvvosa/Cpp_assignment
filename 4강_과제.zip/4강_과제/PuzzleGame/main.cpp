#include "Ranking.h"
extern int playPuzzle();
void main() {
	loadRanking("ranking.bin");
	int rank = playPuzzle();
	printRanking();
	storeRanking("ranking.bin");

}