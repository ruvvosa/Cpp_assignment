#pragma once
#include "Canvas.h"
#include "Monster.h"
#include <Windows.h>
#define DIM 40
#define MAXMONS 20
using namespace std;
class MonsterWorld {
	int map[DIM][DIM];
	int xMax, yMax, nMon, nMove;
	Monster* mon[MAXMONS];   // ������ �迭�� ����
	Canvas canvas;
	int& Map(int x, int y) { return map[y][x]; }
	bool isDone() { return countItems() == 0; }
	int countItems() {
		int nItems = 0;
		for (int y = 0; y < yMax; y++)
			for (int x = 0; x < xMax; x++)
				if (Map(x, y) > 0)nItems++;
		return nItems;
	}
	void checkStarvation() {
		int k = 0;
		while (k < nMon) {
			if (mon[k]->getEnergy() == 0) {
				cout << "\tMonster �ϳ��� �����׽��ϴ�\n";
				delete mon[k];
				mon[k] = mon[nMon - 1];
				mon[nMon - 1] = nullptr;
				nMon--;
			}
			else {
				k++;
			}
		}
	}
	void print() {
		canvas.clear();
		for (int y = 0; y < yMax; y++)
			for (int x = 0; x < xMax; x++)
				if (Map(x, y) > 0) canvas.draw(x, y, "��");
		for (int i = 0; i < nMon; i++)
			mon[i]->draw(canvas);
		canvas.print("[ Monster World (���͵��� ����) ]");
		cout << " ��ü �̵� Ƚ�� = " << nMove << endl;
		cout << " ���� ������ �� = " << countItems() << endl;
		for (int i = 0; i < nMon; i++)
			mon[i]->print();
		Monster::printCount();
	}
public:
	MonsterWorld(int w, int h) :canvas(w, h), xMax(w), yMax(h) {
		nMon = 0;
		nMove = 0;
		for (int i = 0; i < MAXMONS; i++)
			mon[i] = nullptr;  
		for (int y = 0; y < yMax; y++)
			for (int x = 0; x < xMax; x++) Map(x, y) = 1;
	}
	~MonsterWorld() {
		for (int i = 0; i < nMon; i++) {
			delete mon[i];  
			mon[i] = nullptr;
		}
	}
	void add(Monster* m) {    
		if (nMon < MAXMONS) mon[nMon++] = m;
	}
	void play(int maxwalk, int wait) {
		print();
		cout << " ���͸� ��������..." << endl;
		getchar();
		for (int i = 0; i < maxwalk; i++) {
			for (int k = 0; k < nMon; k++)
				mon[k]->move(map, xMax, yMax);
			nMove++;

			checkStarvation(); //�� �ϸ��� �ƻ� üũ

			print();
			if (isDone()) break;
			Sleep(wait);
		}
	}
};